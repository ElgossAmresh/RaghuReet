using System.Security.Cryptography;
using System.Text;

namespace Nop.Plugin.Payments.PhonePe.Services
{
    public class PhonePeService
    {
        public static string GenerateChecksum(string payload, string saltKey, int saltIndex)
        {
            string raw = payload + "/pg/v1/pay" + saltKey;
            using var sha = SHA256.Create();
            var hash = sha.ComputeHash(Encoding.UTF8.GetBytes(raw));
            return BitConverter.ToString(hash).Replace("-", "").ToLower() + "###" + saltIndex;
        }
    }
}