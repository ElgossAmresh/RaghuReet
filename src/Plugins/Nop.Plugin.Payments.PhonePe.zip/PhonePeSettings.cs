using Nop.Core.Configuration;

namespace Nop.Plugin.Payments.PhonePe
{
    public class PhonePeSettings : ISettings
    {
        public string MerchantId { get; set; }
        public string SaltKey { get; set; }
        public int SaltIndex { get; set; }
        public bool UseSandbox { get; set; }
    }
}