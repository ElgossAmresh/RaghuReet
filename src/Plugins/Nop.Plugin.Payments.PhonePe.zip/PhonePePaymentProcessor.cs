using Nop.Core.Domain.Payments;
using Nop.Services.Payments;

namespace Nop.Plugin.Payments.PhonePe
{
    public class PhonePePaymentProcessor : BasePlugin, IPaymentMethod
    {
        public PaymentMethodType PaymentMethodType => PaymentMethodType.Redirection;

        public Task<ProcessPaymentResult> ProcessPaymentAsync(ProcessPaymentRequest request)
        {
            return Task.FromResult(new ProcessPaymentResult
            {
                NewPaymentStatus = PaymentStatus.Pending
            });
        }

        public Task PostProcessPaymentAsync(PostProcessPaymentRequest request)
        {
            return Task.CompletedTask;
        }

        public decimal GetAdditionalHandlingFee(IList<ShoppingCartItem> cart) => 0;
        public bool HidePaymentMethod(IList<ShoppingCartItem> cart) => false;

        public override string GetConfigurationPageUrl()
        {
            return "/Admin/PaymentPhonePe/Configure";
        }
    }
}