using Microsoft.AspNetCore.Mvc;
using Nop.Services.Configuration;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Mvc.Filters;

namespace Nop.Plugin.Payments.PhonePe.Controllers
{
    [AuthorizeAdmin]
    public class PaymentPhonePeController : BasePaymentController
    {
        private readonly ISettingService _settingService;

        public PaymentPhonePeController(ISettingService settingService)
        {
            _settingService = settingService;
        }

        public IActionResult Configure()
        {
            var settings = _settingService.LoadSetting<PhonePeSettings>();
            return View("~/Plugins/Payments.PhonePe/Views/Configure.cshtml", settings);
        }

        [HttpPost]
        public IActionResult Configure(PhonePeSettings model)
        {
            _settingService.SaveSetting(model);
            return Configure();
        }
    }
}