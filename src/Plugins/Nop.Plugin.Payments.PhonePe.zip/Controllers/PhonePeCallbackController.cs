using Microsoft.AspNetCore.Mvc;
using Nop.Services.Orders;

namespace Nop.Plugin.Payments.PhonePe.Controllers
{
    [Route("phonepe/callback")]
    public class PhonePeCallbackController : Controller
    {
        private readonly IOrderService _orderService;

        public PhonePeCallbackController(IOrderService orderService)
        {
            _orderService = orderService;
        }

        [HttpPost]
        public IActionResult Index([FromBody] dynamic response)
        {
            string transactionId = response?.data?.merchantTransactionId;
            if (string.IsNullOrEmpty(transactionId))
                return BadRequest();

            var order = _orderService.GetOrderByGuid(Guid.Parse(transactionId));
            if (order == null)
                return NotFound();

            if (response.code == "PAYMENT_SUCCESS")
            {
                _orderService.MarkOrderAsPaid(order);
            }

            return Ok();
        }
    }
}